public class Ejercicio2 {
    public static void main(String[] args) {
        System.out.println("A");
        int x = 10;
        int y = 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x += 5;
        y -= 15;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x++;        //sumar uno
        y--;        //restar uno
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x *= 4;     //64
        y *= -3;    //-12
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x /= 2;     //división
        y /= 4;     //división
        System.out.println(x);
        System.out.println(y);

        /*
         * 
         * Letra        X       Y
         * A            10      20
         * B            15      5
         * C            16      4
         * D            64      -12
         * E            32      -3
         */
    }
}

