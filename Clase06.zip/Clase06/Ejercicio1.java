public class Ejercicio1 {
    public static void main(String[] args) {
        System.out.println("A");
        int x = 10;
        int y = 20;
        System.out.println(x);              //10
        System.out.println(y);              //20
        System.out.println("B");
        x = x + 5;
        y = y + 10;
        System.out.println(x);              //15
        System.out.println(y);              //30
        System.out.println("C");
        x = x - 5;
        y = y - 10;
        System.out.println(x);              //10
        System.out.println(y);              //20
        System.out.println("D");
        x = x* 3;
        y = y *5;
        System.out.println(x);              //30
        System.out.println(y);              //100
        System.out.println("E");
        x = x/ 2;
        y = y /4;
        System.out.println(x);              //15
        System.out.println(y);              //25


        /*
         * 
         *  Letra           X               Y
         *      A           10              20
         *      B           15              30
         *      C           10              20
         *      D           30              100
         *      E           15              25
         */


    }
}