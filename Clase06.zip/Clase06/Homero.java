import java.util.Scanner;

public class Homero {
    public static void main(String[] args) {
        

        //System.out.println("Homero llevame a monte Splash? (S o N)");  
        //String respuesta=new Scanner(System.in).nextLine();
        //if(!respuesta.equalsIgnoreCase("s")) return;
        //return significa terminar el programa

        String respuesta;
        boolean irAMonteSplash=false;
        while(!irAMonteSplash){
            System.out.println("Homero llevame a monte Splash? (S o N)"); 
            respuesta=new Scanner(System.in).nextLine();
            if(respuesta.equalsIgnoreCase("s")) irAMonteSplash=true;
        }

        //

        System.out.println(Colores.ANSI_YELLOW);
        System.out.println("Vamos a monte Splash");
        System.out.println("""
▒▒▒▒▒▒▒▓
▒▒▒▒▒▒▒▓▓▓
▒▓▓▓▓▓▓░░░▓
▒▓░░░░▓░░░░▓
▓░░░░░░▓░▓░▓
▓░░░░░░▓░░░▓
▓░░▓░░░▓▓▓▓
▒▓░░░░▓▒▒▒▒▓
▒▒▓▓▓▓▒▒▒▒▒▓
▒▒▒▒▒▒▒▒▓▓▓▓
▒▒▒▒▒▓▓▓▒▒▒▒▓
▒▒▒▒▓▒▒▒▒▒▒▒▒▓
▒▒▒▓▒▒▒▒▒▒▒▒▒▓
▒▒▓▒▒▒▒▒▒▒▒▒▒▒▓
▒▓▒▓▒▒▒▒▒▒▒▒▒▓
▒▓▒▓▓▓▓▓▓▓▓▓▓
▒▓▒▒▒▒▒▒▒▓
▒▒▓▒▒▒▒▒▓
      

                """);
            System.out.println(Colores.ANSI_RESET);
            
          
    }
}


